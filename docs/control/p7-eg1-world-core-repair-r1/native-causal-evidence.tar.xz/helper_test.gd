extends SceneTree
const Probe = preload("res://helper.gd")
func _init() -> void:
	var ok: bool = true
	for repaired in [false, true]:
		for mode in [0, 1]:
			var server := ENetMultiplayerPeer.new()
			server.set_bind_ip("127.0.0.1")
			assert(server.create_server(0, 32, 6) == OK)
			if repaired:
				server.host.bandwidth_limit(0, 0)
			var result: Dictionary = Probe.measure_listener(server, 6, mode)
			server.close()
			print(JSON.stringify({"kind": "HELPER_LOGIC_ONLY_NOT_PRODUCTION_PORT", "repaired": repaired, "result": result}))
			ok = ok and bool(result.get("passed", false)) == repaired
			ok = ok and int(result.get("statistics_before_input", {}).get("limit", -1)) == (32 if repaired else 1)
	quit(0 if ok else 1)
