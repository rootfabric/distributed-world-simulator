extends SceneTree

const CHANNELS: int = 6
const WARMUP_MS: int = 2500
const RECEIVE_MS: int = 250

func _pump(server: ENetMultiplayerPeer, client: ENetMultiplayerPeer, duration_ms: int) -> Array:
	var packets: Array = []
	var deadline: int = Time.get_ticks_msec() + duration_ms
	while Time.get_ticks_msec() < deadline:
		server.poll()
		client.poll()
		while server.get_available_packet_count() > 0:
			var mode: int = server.get_packet_mode()
			var channel: int = server.get_packet_channel()
			var payload: PackedByteArray = server.get_packet()
			packets.append({"mode": mode, "channel": channel, "payload": payload.get_string_from_utf8()})
		while client.get_available_packet_count() > 0:
			client.get_packet()
		OS.delay_msec(1)
	return packets

func _case(label: String, restore_bandwidth: bool, disable_rtt: bool) -> Dictionary:
	var server := ENetMultiplayerPeer.new()
	server.set_bind_ip("127.0.0.1")
	var error: Error = server.create_server(0, 32, CHANNELS)
	if error != OK:
		return {"label": label, "error": "SERVER_CREATE", "code": error}
	if restore_bandwidth:
		server.host.bandwidth_limit(0, 0)
	var client := ENetMultiplayerPeer.new()
	error = client.create_client("127.0.0.1", server.host.get_local_port(), CHANNELS)
	if error != OK:
		server.close()
		return {"label": label, "error": "CLIENT_CREATE", "code": error}
	_pump(server, client, 150)
	if client.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		client.close()
		server.close()
		return {"label": label, "error": "CONNECT_TIMEOUT"}
	var peer: ENetPacketPeer = client.get_peer(1)
	if disable_rtt:
		peer.throttle_configure(5000, 2, 0)
	client.set_target_peer(1)
	client.transfer_channel = 3
	client.transfer_mode = MultiplayerPeer.TRANSFER_MODE_RELIABLE
	var reliable_enqueued: Array = []
	for index in range(3):
		reliable_enqueued.append(int(client.put_packet(("item-%d:" % index + "x".repeat(256)).to_utf8_buffer())))
	var before: Array = _pump(server, client, WARMUP_MS)
	var stats := {
		"limit": peer.get_statistic(ENetPacketPeer.PEER_PACKET_THROTTLE_LIMIT),
		"throttle": peer.get_statistic(ENetPacketPeer.PEER_PACKET_THROTTLE),
		"counter": peer.get_statistic(ENetPacketPeer.PEER_PACKET_THROTTLE_COUNTER),
		"deceleration": peer.get_statistic(ENetPacketPeer.PEER_PACKET_THROTTLE_DECELERATION),
	}
	client.transfer_channel = 1
	client.transfer_mode = MultiplayerPeer.TRANSFER_MODE_UNRELIABLE
	var input_enqueue: Error = client.put_packet("move-1".to_utf8_buffer())
	var after: Array = _pump(server, client, RECEIVE_MS)
	var received: bool = false
	for packet in after:
		if packet["payload"] == "move-1":
			received = packet["channel"] == 1 and packet["mode"] == MultiplayerPeer.TRANSFER_MODE_UNRELIABLE
	var result := {
		"label": label, "restore_bandwidth": restore_bandwidth,
		"reliable_enqueue": reliable_enqueued, "reliable_received": before.size(),
		"input_enqueue": int(input_enqueue), "input_received": received,
		"statistics_before_input": stats, "packets_after_input": after,
	}
	client.close()
	server.close()
	return result

func _init() -> void:
	var results: Array = []
	for attempt in range(3):
		results.append(_case("baseline-%d" % attempt, false, false))
		results.append(_case("restore-bandwidth-%d" % attempt, true, false))
		results.append(_case("disable-rtt-only-%d" % attempt, false, true))
	var passed: bool = true
	for result in results:
		if result.has("error"):
			passed = false
			continue
		var restored: bool = result["restore_bandwidth"]
		passed = passed and result["reliable_received"] == 3 and result["input_enqueue"] == OK
		passed = passed and result["input_received"] == restored
		passed = passed and result["statistics_before_input"]["limit"] == (32 if restored else 1)
	var report := {"kind": "NATIVE_CAUSAL_AB_NOT_PRODUCT_ACCEPTANCE", "godot": Engine.get_version_info(), "warmup_ms": WARMUP_MS, "receive_ms": RECEIVE_MS, "passed": passed, "results": results}
	var output := FileAccess.open("res://artifacts/native-ab.json", FileAccess.WRITE)
	output.store_string(JSON.stringify(report, "\t") + "\n")
	output.close()
	print(JSON.stringify(report))
	quit(0 if passed else 1)
